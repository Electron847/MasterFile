#!/bin/bash
# Seth Weber
# Access Control
# April 14, 2020


# create groups
#sudo groupadd <name of group>
sudo groupadd Group1
sudo groupadd Group2
sudo groupadd Group3
sudo groupadd Group4

# assign users to groups
#sudo usermod -a -G <name of group> <user>
sudo usermod -a -G Group1 bard
sudo usermod -a -G Group1 mary
sudo usermod -a -G Group1 bob
sudo usermod -a -G Group1 sam
sudo usermod -a -G Group2 karen
sudo usermod -a -G Group2 tom
sudo usermod -a -G Group2 becky
sudo usermod -a -G Group2 kevin
sudo usermod -a -G Group3 bard
sudo usermod -a -G Group3 mary
sudo usermod -a -G Group3 bob
sudo usermod -a -G Group3 sam
sudo usermod -a -G Group3 karen
sudo usermod -a -G Group3 kevin
sudo usermod -a -G Group4 bard
sudo usermod -a -G Group4 sam
sudo usermod -a -G Group4 karen
sudo usermod -a -G Group4 kevin
sudo usermod -a -G Group4 becky
sudo usermod -a -G Group4 tom

# assign a group to each file
#sudo chgrp <name of group> <file>
sudo chgrp Group1 Jones-Pleading1.txt
sudo chgrp Group1 Jones-Pleading2.txt
sudo chgrp Group1 Santana-Pleading1.txt
sudo chgrp Group1 Santana-Pleading2.txt
sudo chgrp Group2 Johnson-Contract1.txt
sudo chgrp Group2 Johnson-Contract2.txt
sudo chgrp Group3 Jones-Bill1.txt
sudo chgrp Group3 Jones-Bill2.txt
sudo chgrp Group3 Santana-Bill1.txt
sudo chgrp Group3 Santana-Bill2.txt
sudo chgrp Group4 Johnson-Bill1.txt
sudo chgrp Group4 Johnson-Bill2.txt

# set permissions on each file
#sudo -u <user who owns file> chmod <symbolic or octal permission set> <file>
sudo -u bard chmod 664 Jones-Pleading1.txt
sudo -u bard chmod 664 Jones-Pleading2.txt
sudo -u bard chmod 664 Santana-Pleading1.txt
sudo -u bard chmod 664 Santana-Pleading2.txt
sudo -u karen chmod 664 Johnson-Contract1.txt
sudo -u karen chmod 664 Johnson-Contract2.txt
sudo -u sam chmod 660 Jones-Bill1.txt
sudo -u sam chmod 660 Jones-Bill2.txt
sudo -u sam chmod 660 Santana-Bill1.txt
sudo -u sam chmod 660 Santana-Bill2.txt
sudo -u kevin chmod 660 Johnson-Bill1.txt
sudo -u kevin chmod 660 Johnson-Bill2.txt
sudo -u bard chmod 644 Jones-Court1.txt
sudo -u mary chmod 644 Jones-Court2.txt
sudo -u bob chmod 644 Santana-Court1.txt
sudo -u bob chmod 644 Santana-Court2.txt
sudo -u karen chmod 644 Johnson-Meeting1.txt
sudo -u kevin chmod 644 Johnson-Meeting2.txt
