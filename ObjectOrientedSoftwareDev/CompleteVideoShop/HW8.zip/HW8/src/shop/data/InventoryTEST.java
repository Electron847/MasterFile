package shop.data;

//import junit.framework.Assert;
import junit.framework.TestCase;
import shop.command.UndoableCommand;
import shop.command.CommandHistory;
import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
import org.junit.Assert;

// TODO: complete the tests
public class InventoryTEST extends TestCase {
  public InventoryTEST(String name) {
    super(name);
  }
  
  public void testSize() {
    // TODO
  }

  public void testAddNumOwned() {
    // TODO
  }

  public void testCheckOutCheckIn() {
    // TODO
  }

  public void testClear() {
    // TODO
  }

  public void testGet() {
    // TODO
  }

  public void testIterator1() {
    // TODO
  }
  public void testIterator2() {
    // TODO
  }
}
