package HW3;

import java.util.function.BiFunction;

public interface BiFunctionInterface<U, V>
{
    BiFunction sum(U u, U v);
}
