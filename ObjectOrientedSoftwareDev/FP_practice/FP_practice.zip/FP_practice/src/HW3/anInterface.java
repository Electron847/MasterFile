package HW3;

import java.util.function.Function;

public interface anInterface {

    Function listIt(Iterable<Object> myList);
}
