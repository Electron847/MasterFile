package shop.data;

import shop.command.UndoableCommand;
import java.util.Map;

/**
 * Implementation of command to clear the inventory.
 * @see Data
 */
final class CmdClear implements UndoableCommand {
  private InventorySet _inventory;
  private Map<Video,Record> _oldvalue;
  CmdClear(InventorySet inventory) {
    _inventory = inventory;
  }
  public boolean run() {
    if (_oldvalue != null) {
      return false;
    }
    _oldvalue = _inventory.clear();
    _inventory.getHistory().add(this);
    return true;
  }
  public void undo() {
    _inventory.replaceMap(_oldvalue);
  }
  public void redo() {
    _inventory.clear();
  }
}
