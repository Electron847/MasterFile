package shop.ui;

public interface FormtoUI {
	  public UIForm toUIForm(String heading);
}
