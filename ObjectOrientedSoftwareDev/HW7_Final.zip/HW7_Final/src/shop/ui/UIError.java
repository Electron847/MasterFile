package shop.ui;

public class UIError {
  private static final long serialVersionUID = 2008L;
}
