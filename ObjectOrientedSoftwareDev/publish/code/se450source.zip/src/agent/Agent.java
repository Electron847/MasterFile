package agent;

public interface Agent {
  public void run();
}
