package factory.shape1;
import java.awt.Graphics;
public interface Shape {
  void paint(Graphics g);
}
