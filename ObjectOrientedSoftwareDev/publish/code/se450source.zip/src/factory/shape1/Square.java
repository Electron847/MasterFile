package factory.shape1;
import java.awt.Graphics;
public class Square implements Shape {
  public void paint(Graphics g) { /* ... */ }
  // ...
}
