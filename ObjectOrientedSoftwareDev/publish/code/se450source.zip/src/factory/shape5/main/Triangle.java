package factory.shape5.main;
import factory.shape5.Shape;
public class Triangle implements Shape {
  public String toString() {
    return "Triangle";
  }
}
