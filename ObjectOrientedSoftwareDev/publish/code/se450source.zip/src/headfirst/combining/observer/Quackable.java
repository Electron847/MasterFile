package headfirst.combining.observer;

public interface Quackable extends QuackObservable {
	public void quack();
}
