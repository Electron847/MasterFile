package headfirst.observer.WeatherStationObservable;

public interface DisplayElement {
	public void display();
}
