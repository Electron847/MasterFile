package common_

case class Word(word: String, title: String)
case class Book(word: String, title: String)
case object Flush
case object Done
